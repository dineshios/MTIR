//
//  TakePhotoViewController.h
//  test
//
//  Created by ceaselez on 12/12/17.
//  Copyright © 2017 ceaselez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TakePhotoViewController : UIViewController

@end
