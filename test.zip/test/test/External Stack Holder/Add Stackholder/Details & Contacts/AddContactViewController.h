//
//  AddContactViewController.h
//  test
//
//  Created by ceaselez on 27/12/17.
//  Copyright © 2017 ceaselez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddContactViewController : UIViewController
@property(nonatomic, assign) long selectCellIndex;
@property(nonatomic, assign) BOOL update;


@end
