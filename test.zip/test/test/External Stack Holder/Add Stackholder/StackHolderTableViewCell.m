//
//  StackHolderTableViewCell.m
//  test
//
//  Created by ceaselez on 11/12/17.
//  Copyright © 2017 ceaselez. All rights reserved.
//

#import "StackHolderTableViewCell.h"

@implementation StackHolderTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
