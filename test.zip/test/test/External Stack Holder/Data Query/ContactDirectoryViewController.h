//
//  ContactDirectoryViewController.h
//  test
//
//  Created by ceaselez on 15/12/17.
//  Copyright © 2017 ceaselez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactDirectoryViewController : UIViewController

@end
