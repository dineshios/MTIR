//
//  DashBoardCollectionViewCell.m
//  test
//
//  Created by ceaselez on 20/12/17.
//  Copyright © 2017 ceaselez. All rights reserved.
//

#import "DashBoardCollectionViewCell.h"

@implementation DashBoardCollectionViewCell

@end
