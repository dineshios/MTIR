//
//  DashBoardCollectionViewCell.h
//  test
//
//  Created by ceaselez on 20/12/17.
//  Copyright © 2017 ceaselez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DashBoardCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIView *colorView;

@end
