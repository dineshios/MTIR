//
//  ConductMeetingTableViewCell.m
//  test
//
//  Created by ceaselez on 11/01/18.
//  Copyright © 2018 ceaselez. All rights reserved.
//

#import "ConductMeetingTableViewCell.h"

@implementation ConductMeetingTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
