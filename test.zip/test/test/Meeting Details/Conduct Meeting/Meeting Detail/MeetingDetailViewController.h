//
//  MeetingDetailViewController.h
//  test
//
//  Created by ceaselez on 11/01/18.
//  Copyright © 2018 ceaselez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MeetingDetailViewController : UIViewController
@property (nonatomic,weak) NSDictionary *meetingDict;
@end
