//
//  MeetingDetailsTableViewCell.m
//  test
//
//  Created by ceaselez on 05/12/17.
//  Copyright © 2017 ceaselez. All rights reserved.
//

#import "MeetingDetailsTableViewCell.h"

@implementation MeetingDetailsTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)memberTF:(id)sender {
}
@end
