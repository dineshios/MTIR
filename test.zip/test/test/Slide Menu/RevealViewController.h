//
//  RevealViewController.h
//  SWMenuOnTop
//
//  Created by Patrick BODET on 28/03/2016.
//  Copyright © 2016 Patrick BODET. All rights reserved.
//

#import "SWRevealViewController.h"

@interface RevealViewController : SWRevealViewController <SWRevealViewControllerDelegate>

@end
