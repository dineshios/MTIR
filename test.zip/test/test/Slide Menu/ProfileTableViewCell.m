//
//  ProfileTableViewCell.m
//  Ease2Lend
//
//  Created by Dineshkumar Arumugam on 02/07/17.
//  Copyright © 2017 TechnoTackle. All rights reserved.
//

#import "ProfileTableViewCell.h"

@implementation ProfileTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
